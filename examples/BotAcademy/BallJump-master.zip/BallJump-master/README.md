<p align="center">
    <a href="https://www.youtube.com/BotAcademyYT"><img src="https://botacademy.s3.eu-central-1.amazonaws.com/9999_channel_design/logo/900x900.png" alt="Logo" width="150"/></a>
    <br />
    <br />
    <a href="http://choosealicense.com/licenses/mit/"><img src="https://img.shields.io/badge/license-MIT-red.svg?style=flat" alt="MIT License"></a>
    <a href="https://twitter.com/bot_academy/"><img src="https://img.shields.io/twitter/url/https/twitter.com/cloudposse.svg?style=social&label=Follow%20%40bot_academy" alt="Twitter"></a>
    <br />
    <br />
    <i>Unity project using the ML-Agents toolkit</i>
    <br />
    <a href="https://www.youtube.com/watch?v=oxIljzj9JgQ"><i>Video</i></a>
</p>
<hr />
